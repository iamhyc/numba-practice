almost no processing time.
